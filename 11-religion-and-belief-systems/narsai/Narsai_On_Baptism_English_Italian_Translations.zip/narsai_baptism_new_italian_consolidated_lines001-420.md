# Narsai — Omelia XXII, Sul battesimo

## Traduzione italiana provvisoria completa in prosa · Versi siriaci 1–420

Edizione provvisoria leggibile basata sulla trascrizione siriaca non corretta del Digital Syriac Corpus (opera 66), con confronto interpretativo di R. H. Connolly (1909). Prosa di nuova formulazione, non copia di Connolly né traduzione critica definitiva. Le intestazioni seguono tutti i 420 versi numerati in 210 coppie consecutive; il breve responsorio iniziale non è numerato.

### Responsorio non numerato

Benedetta la sorgente che sgorgò sul Giordano. Adamo ne bevve e la sua sete cessò. Fratelli miei, rendiamo grazie.

### 1–2

Chi può ripagare l’amore di Colui che ha formato ogni cosa? Per amore egli venne a dare all’umanità una nascita spirituale.

### 3–4

Troppo piccola è la nostra bocca, troppo poca la nostra profondità, per riconoscere la potenza del Creatore: egli rinnovò la nostra immagine e coprì la nostra colpa.

### 5–6

Nel battesimo, come in una fornace, fuse di nuovo la nostra immagine. Al posto della nostra argilla fece di noi oro spirituale.

### 7–8

Volle plasmarci di nuovo spiritualmente, senza pigmenti, perché la morte non deturpasse più la bellezza della nostra immagine.

### 9–10

O Pittore, che dipingi immagini sulla superficie dell’acqua! Nessuna opposizione arresta la tua arte.

### 11–12

O Artefice, che infondi lo Spirito senza mani e semini vita immortale nella nostra mortalità!

### 13–14

O Comando, davanti al quale ogni difficoltà diviene facile, che doni forza ai deboli con la tua grande potenza!

### 15–16

O Volontà, il cui proposito precede l’azione! Prima ancora di creare, egli vedeva nella propria conoscenza ciò che avrebbe creato.

### 17–18

Quella Volontà già contemplava il disegno che avrebbe manifestato verso di noi. Prima che esistessimo, considerava la nostra creazione fin dal principio.

### 19–20

Prima della nostra prima formazione, l’immagine del nostro rinnovamento era davanti a lui. Insieme al proprio essere custodiva quest’opera nel cuore.

### 21–22

La compì con sapienza, come si addice a Colui che tutto conosce. Saggiamente portò a termine il suo proposito e manifestò la propria potenza.

### 23–24

Fece una seconda creazione per la creazione che aveva fatto al principio, scuotendone via le cose antiche della mortalità.

### 25–26

Volle cancellare dagli esseri mortali la sporcizia della colpa; il suo comando pose la spugna dello Spirito nella mano della nostra natura corporea.

### 27–28

Chi può misurare l’amore della sua volontà verso la nostra stirpe? Dalla nostra umiltà fece uno strumento a cui affidare i suoi sapienti disegni.

### 29–30

Dalla nostra stessa polvere fece tesorieri delle sue ricchezze nascoste; da quella polvere nominò amministratori incaricati di distribuire la vita.

### 31–32

Scelse dei sacerdoti perché facessero da mediatori fra lui e il suo popolo e li inviò come messaggeri agli altri esseri umani.

### 33–34

Affidò loro il grande sigillo della sua divinità, perché con esso imprimessero il segno del rinnovamento di tutta la creazione.

### 35–36

Affidò alla loro custodia le ricchezze inesauribili dello Spirito, da distribuire con amore secondo la grandezza di quel dono.

### 37–38

Insegnò loro un’arte spirituale: tracciare l’immagine della vita vivente sulla superficie dell’acqua.

### 39–40

Quale meraviglia: creature corporee che dipingono per mezzo dello Spirito senza usare le mani! Mortali che introducono la vita in ciò che è mortale!

### 41–42

Quanto in alto è stato innalzato il sacerdozio! Per la potenza di colui che lo ha scelto, la sua autorità si estende nelle altezze e nelle profondità.

### 43–44

Che cosa stupefacente, troppo grande per essere descritta: alla natura mortale è dato di comunicare vita a se stessa, quasi che questa forza le appartenesse.

### 45–46

Quale disegno divino, che si china verso le proprie creature e pone il suo tesoro in una mano umana, affinché la creatura stessa ne sia arricchita.

### 47–48

Quale Creatore, che torna a restaurare l’opera delle sue mani e consegna a quell’opera una penna perché ridisegni da sé la propria immagine!

### 49–50

Chi potrebbe non stupirsi davanti alla grandezza di questo amore benevolo, che rende la nostra stessa argilla capace di creare a somiglianza del Creatore?

### 51–52

Chi potrebbe rifiutarsi di lodare la sua premura per il genere umano? Ha innalzato la nostra umile condizione verso il suo stesso essere incomprensibile.

### 53–54

Alla nostra natura, insieme al suo rinnovamento, ha dato parte della propria autorità, affinché possa far sorgere una nuova creazione non più soggetta alla morte.

### 55–56

Soffiò la forza della vita nella nostra carne, che genera passioni; e quella carne cominciò a parlare di realtà spirituali che non poteva vedere.

### 57–58

Mostrò alla nostra anima qualcosa della propria arte creatrice; così essa ricevette la capacità di far sorgere una creazione, come fa il Creatore.

### 59–60

Per mezzo di una parola che viene da lui, gli esseri umani prendono forma nel grembo delle acque e vengono plasmati spiritualmente, senza il tocco di mani.

### 61–62

Questo mistero supera ciò che le parole riescono a spiegare. Solo la volontà divina nascosta potrebbe dirne il significato così com’è davvero.

### 63–64

Una mente resa limpida nell’anima può contemplarlo; ne vede la maestà con l’intelligenza, non con gli occhi del corpo.

### 65–66

Il suo argomento è troppo profondo perché se ne possa parlare soltanto in termini corporei; la ricerca sale troppo in alto per giungere a compimento con la sola comprensione terrena.

### 67–68

La vicenda del rinnovamento della nostra immagine è intessuta spiritualmente. Senza lo Spirito, nessuna bocca umana può davvero interpretarla.

### 69–70

Un rimedio per la ferita del nostro peccato è stato preparato in modo celeste; se la mente non si eleva verso quell’altezza, non saprà riconoscere la medicina.

### 71–72

Il Maestro supremo ha esposto la lezione della nostra salvezza e della vita; il discepolo deve seguirne il modello per comprendere ciò che gli viene insegnato.

### 73–74

Venite, discepoli di Cristo nostro Maestro: osservate con attenzione gli scritti spirituali del battesimo.

### 75–76

Venite, eredi di un’alleanza scritta nel sangue: considerate con l’occhio dello Spirito ciò che avete ricevuto in eredità.

### 77–78

Venite, esaminate con amore la ricchezza che vi è stata affidata e lodate colui che arricchisce gli esseri umani attingendo ai propri tesori.

### 79–80

Radunatevi, figli purificati nel battesimo: descriviamo la voce che risuona nelle acque e comunica loro la forza.

### 81–82

Venite, guardate con intelligenza la mano di carne che seppellisce i corpi e poi li rialza prontamente.

### 83–84

Preparatevi a vedere un prodigio nel santuario: le potenze del cielo si raccolgono per assistere al mistero della nostra liberazione.

### 85–86

Ora è il momento per chi assiste di disporsi ordinatamente. Ognuno rivolga lo sguardo della mente a ciò che viene detto.

### 87–88

Guardate: il sacerdote si prepara a entrare nel Santo dei Santi, per aprire l’ingresso al regno celeste a quanti desiderano entrarvi.

### 89–90

Guardate: si avvicina alla soglia della dimora regale, per ricevere la forza necessaria ai misteri che le sue mani celebreranno.

### 91–92

Guardate: il Re dei cieli gli tende la mano dello Spirito e depone nella sua mano il sigillo del Nome divino, con il quale segnare le sue pecore.

### 93–94

Guardate: riveste il sacerdote della veste gloriosa degli immortali, affinché possa coprire la vergogna di coloro che la colpa ha lasciato esposti.

### 95–96

Guardate: lo manda a prendersi cura del gregge affidatogli. Il sacerdote alza la voce e chiama ciascuna pecora per nome.

### 97–98

Guardate: pecore, agnelli e madri si radunano, ed egli imprime su di loro il sigillo che dà vita, portato dalla parola del loro Signore.

### 99–100

Guardate: mediante le parole che pronunciano li conduce, per così dire, dentro una fornace, chiedendo loro un’unica professione del Nome del Creatore.

### 101–102

Il comando divino tiene il sacerdote come si tiene una penna; ma è una scrittura spirituale quella che, per suo mezzo, registra il corpo e l'anima nel libro della vita.

### 103–104

La parola della sua bocca diventa un bastone che scaccia le tenebre dell'errore, quelle tenebre che avevano accecato i candidati e impedito loro di comprendere.

### 105–106

Alza la voce e li invita a rinunciare al Maligno, al suo potere, ai suoi angeli, al suo servizio e agli errori con cui trae in inganno.

### 107–108

Prima respingono il dominio di colui che li aveva resi schiavi; poi riconoscono la potenza del Creatore che li ha liberati.

### 109–110

Due dichiarazioni sono richieste a chi si accosta ai misteri della Chiesa: il rifiuto del male e la professione di fede nel Creatore.

### 111–112

Il candidato proclama ad alta voce: «Rinuncio al Maligno e ai suoi angeli. Non avrò più nulla in comune con lui, neppure a parole».

### 113–114

Il sacerdote si pone come mediatore e domanda: «Di chi vuoi essere servo, da questo momento in poi?».

### 115–116

Apprende così chi il candidato desidera chiamare Signore; quindi lo iscrive nel numero dei primogeniti del cielo.

### 117–118

Il volto del candidato viene distolto da Satana e dai suoi angeli; poi il sacerdote traccia sulla sua fronte l'immagine, o segno, della divinità.

### 119–120

Egli rinnega il Maligno perché malvagi sono i suoi rapporti con gli uomini, e rinnega i suoi angeli perché avversari della parola di verità.

### 121–122

Il Maligno e quanti lo seguono odiano la verità; perciò chi ama la verità deve rifiutare di schierarsi con loro.

### 123–124

Il candidato ripeta con Davide, figlio di Iesse: «Signore, ho odiato coloro che ti odiano». Chieda che sia fatta giustizia dell'offesa recata al nome del Creatore.

### 125–126

Chi si avvicina al battesimo entra in lotta con Satana, con i suoi angeli e con il servizio che egli pretende dagli uomini.

### 127–128

Narsai chiama «angeli» di Satana alcuni uomini rivestiti d'inganno: a suo giudizio, servono la menzogna attraverso pratiche colme di malvagità.

### 129–130

Fra questi colloca Mani: un lupo insidioso che assume l'aspetto di un agnello e trascina fuori strada le pecore del gregge.

### 131–132

Nomina poi Valentino, accusato di falsare la verità e di oscurare con discorsi vani la risurrezione dei morti.

### 133–134

Nomina anche Ario, contro il quale si scaglia per aver insegnato una disuguaglianza nella divinità: paragona tale dottrina a una malattia peggiore della lebbra.

### 135–136

Segue Eunomio, descritto come un serpente astuto, i cui morsi avvelenati feriscono l'anima di chi gli presta ascolto.

### 137–138

Un altro bersaglio è Apollinare: secondo Narsai introduce la falsità proprio nell'edificio della verità, senza provarne vergogna.

### 139–140

Cita inoltre Paolo, accusandolo di sminuire ostinatamente la potenza del Verbo del Padre.

### 141–142

Aggiunge Eutiche, che, secondo lui, cade in errore attribuendo il patire a Colui che non è soggetto alla sofferenza.

### 143–144

Come un mercante che adultera la propria merce, questo maestro, accusa Narsai, mescola la natura divina vivente con le sofferenze del corpo.

### 145–146

Narsai giudica la sua colpa persino più grave di quella degli altri, e sostiene che così egli offre un aiuto ancora maggiore all'Accusatore.

### 147–148

Per mezzo di tali dottrine, dice Narsai, il nemico dell'umanità svia le menti e vi versa l'amarezza del proprio inganno.

### 149–150

I suoi seguaci praticano le diverse forme di quel servizio corrotto e vi aggiungono nuove invenzioni menzognere.

### 151–152

Il culto di cui si vantano, nell'aspro giudizio di Narsai, è un servizio reso all'ingannatore: i misteri che vi si annunciano non sono quelli della verità.

### 153–154

Accusa i maestri da lui chiamati eretici di servire quel nemico in molte forme, di perdersi nelle sue astuzie e di trascinare nell'errore anche chi li ascolta.

### 155–156

Per questo esorta a starne lontani, come si evita ciò che è impuro, e a non prendere parte alle pratiche che condanna.

### 157–158

Invita a chiamare malvagie tali opere, a voltare loro le spalle e a non partecipare ai loro riti.

### 159–160

Le invenzioni del Maligno e di quanti lo ascoltano, afferma Narsai, sono piene d'ingiustizia; sotto un'apparente abilità nascondono mali profondi.

### 161–162

Egli include circhi, gare negli stadi, teatri e canti chiassosi composti per quegli spettacoli fra le distrazioni legate a tale errore.

### 163–164

Menziona anche divinazioni e arti magiche d'ogni genere, gesti seducenti degli occhi, suoni che lusingano l'udito e incontri lungo la strada che attirano fuori via.

### 165–166

Chi diventa discepolo della verità rinuncia a queste cose durante l'istruzione. Soltanto allora si presenta a professare la fede.

### 167–168

Il candidato manifesta con voce udibile la decisione del cuore: «Ho lasciato il Maligno e mi sono rivolto al Creatore».

### 169–170

La dichiarazione pronunciata ad alta voce confonde i demoni: «Ascoltatemi, ribelli! Non ho più nulla in comune con voi».

### 171–172

La sua professione di fede rallegra le assemblee del cielo: «Venite, esseri spirituali, gioite con me! Sono sfuggito alla rovina e sono tornato alla vita».

### 173–174

«Sono vostro compagno nel servizio e desidero partecipare alle vostre opere. Anch'io voglio servire il Signore al quale voi prestate servizio».

### 175–176

Così il viandante si presenta come soldato del regno celeste: un fuggiasco che ritorna per cercare rifugio presso il Re dei re.

### 177–178

Per prima cosa supplica gli amministratori della santa Chiesa di condurlo alla porta del Re, perché la sua richiesta possa essere ascoltata.

### 179–180

Questi amministratori sono i sacerdoti che celebrano i misteri. A loro è stato affidato il tesoro dello Spirito, affinché ne distribuiscano le ricchezze.

### 181–182

Il viandante, come un esule, si avvicina a uno di questi sacerdoti e chiede di essere liberato dal potere del Maligno che l'aveva fatto prigioniero.

### 183–184

Sta davanti al sacerdote come un esiliato privo di vesti e di protezione, mostrando la fatica e le sofferenze patite nella casa dei suoi carcerieri.

### 185–186

«Per amore del Re», grida il prigioniero ai servi della corte, «andate dal Re e intercedete per me, perché mi accolga con benevolenza».

### 187–188

«Entrate e ditegli: uno dei tuoi servi è tornato dalla prigionia. Ti supplica con amore di poter vedere il tuo volto».

### 189–190

«Sono stato fatto schiavo da un servo che si è ribellato alla tua sovranità. Libera la mia vita dal suo potere, perché non possa più umiliarmi».

### 191–192

«Sono tuo servo, Signore buono, figlio della tua serva. Perché dovrei servire uno schiavo malvagio che si è rivoltato contro di te?».

### 193–194

«Perché ho servito ingiustamente colui che commette ogni ingiustizia? Strappami dalle sue mani. Fa' che io sia tuo, perché tuo già sono».

### 195–196

Questo è il discorso che il viandante compone nel giorno del ritorno, secondo il modello della parabola del figlio minore.

### 197–198

La parabola fu narrata anche per lui; è giusto che la sua supplica riprenda le parole tramandate dalla Scrittura.

### 199–200

È lui colui del quale parla il Vangelo: si smarrì, partì, cambiò strada e fece ritorno. La sua partenza e il suo pentimento vi sono ricordati.

### 201–202

Ora il racconto scritto diventa realtà, e una misericordia sovrabbondante gli esce incontro per riceverlo e accoglierlo.

### 203–204

Le assemblee celesti festeggiano il suo pentimento e lo accompagnano come un morto che sia tornato alla vita.

### 205–206

Soltanto l'Accusatore si rattrista per quel ritorno: il prigioniero ha spezzato le sue reti, infranto i lacci, lo ha abbandonato ed è fuggito.

### 207–208

Il peccatore è scampato alla schiavitù amara e ha trovato rifugio presso il Signore buono, dolce nel suo amore.

### 209–210

L'esule ritorna dall'esilio a Colui che lo ha plasmato. Ora chiede il permesso di entrare e di contemplare il volto del Re.

### 211–212

La sua supplica diventa un'accusa contro chi lo teneva prigioniero: in base alla stessa legge di Dio egli chiama il suo oppressore a rispondere.

### 213–214

Affida la penna delle parole pronunciate ai servi del Re; essi mettono il caso per iscritto e lo presentano al Giudice.

### 215–216

Chiede ai sacerdoti di fargli da difensori nella causa intentata contro di lui. Mentre egli tace, essi parlano in suo favore.

### 217–218

Nell'ora dei misteri il sacerdote si presenta come in un tribunale, per accusare il diavolo in nome dei peccatori.

### 219–220

Anche il peccatore sta in piedi come un povero spogliato dei suoi beni e supplica che la misericordia lo soccorra nel giudizio.

### 221–222

Nudo e senza riparo davanti al Giudice, lascia che la sua miseria e la sua vergogna parlino per lui, sperando che la compassione lo rivesta.

### 223–224

Senza nulla dietro cui nascondersi, presenta la sua causa contro l'avversario, affinché il Re lo veda e gli renda prontamente giustizia.

### 225–226

Piega le ginocchia e china il capo per la vergogna: non osa levare gli occhi verso il Giudice celeste.

### 227–228

Indossa il sacco e si avvicina a chiedere pietà, ricordando il tempo in cui era soggetto al Maligno.

### 229–230

Il suo inginocchiarsi durante i misteri rappresenta due cose insieme: la caduta e il debito che è tenuto a saldare.

### 231–232

In quella posizione ricorda la caduta nel Paradiso e intenta causa a Satana, che aveva sviato il suo progenitore.

### 233–234

Per la paura tiene lo sguardo rivolto alla terra finché non ode una parola di perdono. Soltanto allora ritrova coraggio.

### 235–236

Attende che il sacerdote presenti la sua supplica al Giudice e gli restituisca, mediante l'olio e l'acqua, il documento della libertà.

### 237–238

Conduce inoltre un garante nel luogo del giudizio, affinché testimoni la sincerità della sua preparazione e del suo desiderio.

### 239–240

Promette con cuore sincero di rimanere fedele alla verità; il suo compagno se ne fa garante e conferma che la promessa è autentica.

### 241–242

Quel compagno diventa guida delle sue parole e delle sue azioni, indicandogli come condurre una vita spirituale.

### 243–244

Lo chiama per nome e lo presenta ai custodi, perché venga riconosciuto erede, figlio e cittadino del regno.

### 245–246

Il sacerdote iscrive nei registri il nome di chi era smarrito e lo depone fra gli archivi regali.

### 247–248

Lo pone come una pecora alla porta dell'ovile, segna il suo corpo e introduce il nuovo arrivato nel gregge.

### 249–250

Davanti ai presenti tiene in mano il segno tracciato con l'olio: mediante ciò che si vede, annuncia la potenza di ciò che rimane nascosto.

### 251–252

È un simbolo offerto agli occhi del corpo, che indica la forza invisibile celata nell'unzione visibile.

### 253–254

O uomo plasmato dalla terra, che marchi il gregge con il segno del suo Signore! Mediante un simbolo esteriore vi imprimi il suo Nome nascosto.

### 255–256

O ministro nato dalla polvere, che porti lo Spirito sulla punta della lingua! Con le parole della bocca recidi il peccato dell'anima e del corpo.

### 257–258

O mortale, che custodisci in bocca una sorgente immensa! Offri a quelli della tua stessa stirpe da bere una vita che non muore.

### 259–260

O povero, figlio di poveri, divenuto ricco d'un tratto! Ora distribuisci l'abbondanza dello Spirito, ricchezza che i tuoi antenati non possedevano.

### 261–262

O creatura nata dalla terra, la cui stessa polvere rivela la propria umiltà! Eppure le è stato dato il potere di plasmare per sé una creazione nuova.

### 263–264

Il Buono ha insegnato ai figli della sua casa l'opera della nuova creazione, perché, mediante l'arte del suo stesso creare, potessero rinnovare ciò che era stato fatto.

### 265–266

La colpa umana abbatté l'opera sublime delle sue mani; ed egli diede agli uomini il potere di ricostruirla.

### 267–268

Vide la propria opera invecchiata e logorata dalla mortalità e le aprì una via verso la vita che non muore.

### 269–270

Vide vacillare le colonne della sua casa sotto il peso del patire; pose allora le fondamenta nel profondo delle acque e le rese salde.

### 271–272

Per mezzo dell'acqua cedevole volle dare fermezza ai corpi fragili e, con la forza dello Spirito, stabilità a facoltà ormai indebolite.

### 273–274

Il suo comando preparò una misteriosa fornace d'acqua, riscaldandola non con la fiamma comune ma con lo Spirito e la potenza della sua volontà.

### 275–276

Rese la creatura che aveva plasmato artefice del proprio restauro, capace di essere rifusa nella fornace delle acque e nel calore dello Spirito.

### 277–278

Venite a contemplare il prodigio compiuto nell'umanità mortale: mediante il ministero che le è stato affidato, il mortale muore e torna a vivere.

### 279–280

Venite a indagare il mistero della nostra morte nelle acque, e il prodigio che vi si compie per noi, al di là di quanto l'occhio può vedere.

### 281–282

Avviciniamoci ai custodi dei tesori della Chiesa e ascoltiamo in che modo, attraverso l'acqua, essi donano la vita.

### 283–284

Entriamo con loro nel Santo dei Santi nascosto e impariamo a comprendere i misteri del morire e del vivere.

### 285–286

Il battesimo è mistero insieme di morte e di vita: le due azioni diventano una sola nell'unico ministero sacerdotale.

### 287–288

Il Creatore ha voluto manifestare la sua potenza per mezzo dei sacerdoti, affidando al loro servizio la grande ricchezza della sua bontà.

### 289–290

Ha stabilito i sacerdoti amministratori dei suoi beni, perché come servi fedeli distribuiscano le ricchezze ai figli della sua casa.

### 291–292

A loro ha consegnato il sigillo del suo Nome divino, incomprensibile, affinché imprimano sugli uomini quel Nome santo.

### 293–294

Imprimono continuamente il segno di quel Nome sul suo gregge: ministri umani segnano altri uomini nel Nome trino.

### 295–296

Il sacerdote tiene sulle punte delle dita l'olio come fosse una lama di ferro, e con il suo filo segna il corpo e le facoltà dell'anima.

### 297–298

Con le parole della bocca questo ministro mortale rende affilato l'olio, quasi temprasse il ferro per recidere il peccato.

### 299–300

Pronuncia ordinatamente i tre Nomi, uno dopo l'altro, e mediante questa triplice invocazione porta a compimento il mistero della nostra liberazione.

### 301–302

O fragile uomo, quale prodigio possente si compie attraverso il tuo servizio! Nessuna bocca riesce a esprimere tutta la forza del suo significato.

### 303–304

O umile, quanto in alto è stata innalzata la tua debolezza! La mente non riesce a seguirti fino al luogo che hai raggiunto.

### 305–306

O uomo — e qui mi rivolgo al sacerdote — quale autorità ti è stata concessa: sei stato incaricato di offrire la vita stessa.

### 307–308

Mediante il proprio ministero il sacerdote dona vita ai suoi simili e apre davanti ai compagni di servizio una strada verso la vita futura.

### 309–310

Diventa bocca delle membra del corpo e delle facoltà dell'anima, annunciando a nome di tutti le parole che proclamano il perdono.

### 311–312

Dispone l'olio e l'acqua come fondamenta, e su di esse, con le parole pronunciate, innalza il Nome dell'Essere divino.

### 313–314

Con l'olio che scorre e l'acqua cedevole fonde di nuovo il corpo; al posto della semplice argilla lo trasforma in oro puro.

### 315–316

Chi non si stupirebbe che alla nostra povertà sia stato concesso tanto potere, da arricchirsi grazie a un dono che supera ogni comprensione?

### 317–318

Come custode di tesori, il sacerdote sta alla porta del santuario e usa le chiavi delle parole della sua bocca per aprire la via della vita.

### 319–320

Invoca i tre Nomi sull'olio e lo consacra, perché con la sua santità possa purificare l'impurità degli uomini.

### 321–322

Con il Nome invisibile segna il corpo visibile; la forza penetrante di quel Nome arriva sino all'anima.

### 323–324

Che meraviglia vedere ciò che un uomo compie per mezzo di una potenza che non gli appartiene: segna corpi fragili, eppure l'interiorità ne avverte l'effetto.

### 325–326

Agisce anche come medico delle membra: tocca ciò che sta all'esterno e l'azione risanatrice raggiunge ciò che è dentro.

### 327–328

Offre i rimedi della propria arte al corpo e all'anima, e con la forza divina guarisce ciò che si vede e ciò che resta nascosto.

### 329–330

Con l'aiuto di Dio prepara il rimedio affidato alle sue mani e, grazie alla sua potenza, cura ogni malattia senza venir meno.

### 331–332

Apre la porta del tempio santo come quella di una farmacia di rimedi, curando le infermità e fasciando le ferite dei compagni di servizio.

### 333–334

Con un segno esteriore raggiunge le malattie nascoste nell'intimo e applica poi la medicina dello Spirito mediante il simbolo dell'acqua.

### 335–336

Con voce udibile proclama la potenza che agisce nel segreto, mentre la sua lingua distribuisce ricchezze spirituali.

### 337–338

Mentre segna il gregge, fa risuonare parole nelle sue orecchie; e il gregge ascolta con amore i tre Nomi proclamati.

### 339–340

Sigilla le proprie parole nel Nome del Padre, del Figlio e dello Spirito, e in quei Nomi conferma la persona che riceve il battesimo.

### 341–342

Il sacerdote traccia i tre Nomi sul volto del battezzando come uno scudo protettivo, perché il tiranno veda impressa sulla fronte umana l'immagine della maestà divina.

### 343–344

Per questo la fronte viene segnata: per confondere i demoni. Quando riconoscono quel segno sul capo di un essere umano, sono svergognati e respinti.

### 345–346

Anche per questa ragione si celebrano i misteri dell'olio e dell'acqua: perché diventino un'armatura contro gli assalti degli spiriti e la guerra invisibile che essi conducono.

### 347–348

L'olio con cui sono unti i nati dalla terra è una difesa. Muniti di esso, non devono lasciarsi catturare dagli spiriti ostili nella battaglia sottratta agli occhi.

### 349–350

Essi portano il grande sigillo del Re dei re, impresso su di loro affinché prendano posto come soldati nella lotta spirituale.

### 351–352

Sulla fronte ricevono il segno dell'arruolamento spirituale, un marchio luminoso davanti agli angeli e agli uomini.

### 353–354

Stanno come soldati coraggiosi alla porta del Re; e il sacerdote si pone alla loro testa, comandante davanti al proprio esercito.

### 355–356

Nell'ora dei misteri egli dispone le loro file come all'inizio di una battaglia e li prepara a scagliare frecce acute contro l'avversario.

### 357–358

Quelle frecce sono parole: le pone sulle loro labbra e le orienta contro il Maligno, del quale un tempo erano stati prigionieri.

### 359–360

Mette davanti ai loro occhi un bersaglio verso cui mirare; e tende le parole sulle loro lingue come frecce trattenute dalla corda dell'arco.

### 361–362

Quando comincia la lotta, essi vengono sottoposti a una prova: ciò che professano rivela l'intenzione della mente e misura la loro prontezza.

### 363–364

Il sacerdote rimane davanti alla schiera e indica loro il vero bersaglio, perché sappiano orientare rettamente la risposta e la fedeltà.

### 365–366

Rinunciano allo stendardo del Maligno, alla sua potenza e ai suoi angeli. Poi il sacerdote segna le loro fronti con lo stendardo del Re. **[Il passo siriaco ripete un'espressione relativa al segno o al bersaglio: lettura da rivedere.]**

### 367–368

Rinuncia e professione di fede sono inseparabili: respingono il Maligno e, senza divisione del cuore, confessano la loro fede nel Nome divino.

### 369–370

Mediante il ministero sacerdotale stringono un'alleanza con Dio, promettendo che le loro azioni non li ricondurranno al servizio di Satana. **[Nel testo siriaco è incerta una forma riferita al sacerdozio.]**

### 371–372

Affidano al sacerdote il loro impegno con parole che nascono dalla mente e dal cuore. Egli presenta quella promessa al beneplacito di Dio, come fosse sottoposta al Re.

### 373–374

Egli tiene, per così dire, il registro posto all'ingresso della dimora regale: dal palazzo ha ricevuto l'autorità di iscrivere i nomi degli uomini.

### 375–376

Chiama per nome i servi del Re, li fa avanzare uno a uno e imprime sul volto di ciascuno il segno dell'olio.

### 377–378

Con parole udibili dichiara la potenza nascosta in questo gesto. Fa sapere a chi appartengono quelle persone e di chi portano il Nome come sigillo.

### 379–380

Di ciascuno proclama: «Questa persona è serva del Re dei re, in alto e in basso; porta impresso il suo Nome per servirlo secondo la sua volontà».

### 381–382

Il sacerdote unisce il Nome divino all'olio che ha fra le mani e, mentre traccia il segno, invoca il Padre, il Figlio e lo Spirito Santo.

### 383–384

Dichiara: «Questa persona è segnata con i tre Nomi uguali». Fra loro, proclama, non c'è né maggiore né minore per età o dignità.

### 385–386

Non dice: «Io segno questa persona», ma: «Questa persona è segnata». Il sigillo che imprime non appartiene a lui, bensì al suo Signore.

### 387–388

È un mediatore scelto per grazia a prestare il proprio ministero. Poiché la forza non è sua, tale ministero può cacciare il peccato e donare lo Spirito.

### 389–390

L'olio visibile manifesta la forza invisibile racchiusa nei Nomi divini, una forza capace di sostenere dall'interno la nostra debolezza.

### 391–392

Invoca i tre Nomi mentre unge tutta la persona, perché i demoni ostili e le passioni tormentose non possano recare danno a chi riceve il segno.

### 393–394

Non è l'olio, da solo, a proteggere l'essere umano dal male: è la potenza divina che dà forza alla nostra fragilità.

### 395–396

L'olio è un segno che annuncia la potenza di Dio: mediante qualcosa di visibile, egli dà certezza dell'opera che compie nel segreto. **[La formulazione precisa del verso 396 è problematica.]**

### 397–398

Per quella potenza, corpo e anima ricevono coraggio e vigore rinnovati e non devono più tremare davanti alle offese della morte.

### 399–400

Come atleti scendono nell'arena per combattere i pensieri vili e ingannevoli che sorgono nel loro intimo.

### 401–402

Questa forza è comunicata nell'unzione: non perché l'olio la possieda da sé, ma perché è lo Spirito a conferirgliela.

### 403–404

Lo Spirito rende efficace l'unzione compiuta con l'olio fragile e ne rende saldo l'effetto attraverso la santa azione che vi si celebra.

### 405–406

Così il corpo e le facoltà interiori dell'anima sono rafforzati, e coloro che hanno ricevuto il segno escono fiduciosi a contrastare il Maligno.

### 407–408

I demoni vedono il sigillo del Nome di Dio su una persona e indietreggiano, poiché riconoscono il Nome venerabile che quel segno porta.

### 409–410

Il Nome divino risplende dal segno posto fra gli occhi; e gli spiriti astuti si vergognano persino di guardarlo.

### 411–412

Un secondo Sole è sorto dall'alto sul capo dell'uomo. Con i suoi raggi disperde l'errore, seconda tenebra.

### 413–414

Vieni, essere umano: loda ed esalta Colui che ti ha onorato! Con il suo dono ha reso persino il tuo corpo simile a un secondo sole.

### 415–416

Vieni, tu che gli devi tutto: paga il tuo debito con la lode. Egli ti ha riscattato dalla schiavitù del Maligno e della Morte.

### 417–418

Vieni, creatura mortale: glorifica la potenza di Dio, che ha posto nella tua esistenza mortale la capacità di seminare vita.

### 419–420

Con tutte le voci, discendenti di Adamo, figli della terra, innalzate il vostro grido a Colui che vi ha sollevati dalla polvere verso la sua stessa grandezza.

## Edizione di lavoro · fonti e cautele

Prima stesura completa, non certificata da uno studioso di siriaco. La trascrizione siriaca non è stata integralmente collazionata con la stampa originale di Mingana; vocali, punti e varianti non sono stati del tutto verificati. Sono da rivedere, fra gli altri, i versi 16, 32, 36, 54, 71–72, 365–366, 369–370, 395–396. Le accuse contro i teologi nei versi 127–160 sono polemica storica di Narsai e non giudizi redazionali. I confini di alcuni periodi e vari termini liturgici e giuridici richiedono controllo specialistico. Questa versione non segue il metro poetico siriaco.

**Syriac source / Fonte siriaca:** Digital Syriac Corpus, work / opera 66; transcription / trascrizione William Toma; TEI James E. Walters; CC BY 4.0, https://raw.githubusercontent.com/srophe/syriac-corpus/main/data/tei/66.xml. **Interpretive check / Confronto:** R. H. Connolly, *The Liturgical Homilies of Narsai* (1909), pp. 33–45.
