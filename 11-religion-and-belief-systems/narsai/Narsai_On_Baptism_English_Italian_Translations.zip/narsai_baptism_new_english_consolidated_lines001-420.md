# Narsai — Homily XXII, On Baptism

## Complete provisional English prose translation · Syriac lines 1–420

A complete readable working edition based on the uncorrected Syriac transcription in Digital Syriac Corpus work 66, with R. H. Connolly (1909) used for interpretive comparison. This is newly phrased prose, not a reproduction of Connolly or a completed critical translation. Paragraph headings preserve all 420 numbered Syriac lines as 210 consecutive pairs; the brief opening response is unnumbered.

### Unnumbered response

Blessed is the spring that flowed over the Jordan. Adam drank from it, and his thirst passed away. My brothers, let us give thanks.

### 1–2

Who can repay the love of the One who fashioned everything? Out of love he came to give humanity a spiritual birth.

### 3–4

Our mouths are too small, and our depths too shallow, to acknowledge the Creator’s power: he renewed our image and covered our wrongdoing.

### 5–6

In baptism, as in a furnace, he melted down our image. In place of our clay he made us into spiritual gold.

### 7–8

He wished to fashion us anew in a spiritual way, without pigments, so that death would no longer spoil the beauty of our image.

### 9–10

O Painter, who paints images on the surface of water! Opposition does not hinder your craftsmanship.

### 11–12

O Artisan, who breathes the Spirit without hands, and sows immortal life within mortality!

### 13–14

O Command, before whom every difficulty becomes easy, who gives strength to the weak through your great power!

### 15–16

O Will, whose intention precedes its deed! Even before he created, he saw in his knowledge what he was to create.

### 17–18

That Will already saw the purpose it would show toward us. Before we existed, it contemplated our creation from the beginning.

### 19–20

Before our first making, the image of our renewal stood before him. Alongside his own being, he held this work in his heart.

### 21–22

He carried it out in wisdom, as befitted the One who knows all. Wisely he fulfilled his purpose and revealed his power.

### 23–24

He made a second creation for the creation he had made at the beginning, shaking from it the old things of mortality.

### 25–26

He wished to wipe the grime of wrongdoing from mortals; his command placed the sponge of the Spirit in the hand of our bodily nature.

### 27–28

Who can measure the love of his will toward our race? He made our lowliness an instrument entrusted with his wise purposes.

### 29–30

From our very dust he made treasurers of his hidden riches; from that dust he appointed stewards to distribute life.

### 31–32

He chose priests to stand between himself and his people, and sent them as messengers to other human beings.

### 33–34

Into their care he put the great seal of his divinity, so that they might mark with it the renewal of all creation.

### 35–36

He placed in their keeping the inexhaustible riches of the Spirit, to be shared generously, in keeping with the greatness of that gift.

### 37–38

He taught them a spiritual craft: to draw the likeness of living life upon the surface of water.

### 39–40

What a wonder: bodily creatures painting by the Spirit without using their hands! Mortals bringing life into what is mortal!

### 41–42

How high the priesthood has been raised! By the power of the One who chose it, its authority reaches through the heights and the depths.

### 43–44

What an astonishing thing, too great to describe: mortal nature is made to give life to itself, almost as though this power were its own.

### 45–46

What a divine purpose, stooping toward its own creatures and putting its treasure into a human hand, so that the creature itself might become rich.

### 47–48

What a Creator, coming back to set his handiwork right and handing that handiwork a pen with which to draw its own likeness anew!

### 49–50

Who could fail to marvel at the magnitude of this gracious love, which makes our very clay an agent of creation in the Creator’s likeness?

### 51–52

Who could refuse to praise his care for our human race? He has lifted our lowly condition toward his own incomprehensible being.

### 53–54

He gave our nature a share in his authority, together with its renewal, so that it might bring forth a new creation no longer subject to death.

### 55–56

He breathed the strength of life into our flesh, which gives birth to passions; and that flesh began to speak of spiritual realities it could not see.

### 57–58

He showed our soul something of his own art of making; thus it received the power to bring forth a creation, as the Creator does.

### 59–60

By a word that comes from him, human beings are formed in the womb of the waters and shaped spiritually, without the touch of hands.

### 61–62

This mystery rises beyond what words can adequately explain. Only the hidden divine Will could tell its meaning just as it is.

### 63–64

A mind purified within the soul can contemplate it; it sees its majesty through understanding rather than with bodily eyes.

### 65–66

Its subject is too weighty to be spoken of in merely bodily terms; the search reaches too high to be completed by earthly understanding alone.

### 67–68

The story of how our image is renewed is woven in a spiritual way. Without the Spirit, no human mouth can truly interpret it.

### 69–70

A remedy for the wound of our sin has been prepared in a heavenly manner; unless the mind rises toward that height, it will not perceive the medicine.

### 71–72

The supreme Teacher has set out the lesson of our salvation and life; the pupil must follow the pattern in order to understand what is being taught.

### 73–74

Come, disciples of Christ our Teacher: look attentively into the spiritual writings of baptism.

### 75–76

Come, heirs of a covenant written in blood: consider with the eye of the Spirit what you have inherited.

### 77–78

Come, examine with love the wealth entrusted to you, and praise the One who enriches human beings from his storehouses.

### 79–80

Come together, children made clean in baptism: let us describe the voice that calls within the waters and gives them power.

### 81–82

Come, look with understanding at the hand made of flesh that buries bodies and then swiftly raises them again.

### 83–84

Prepare to see a wonder in the holy sanctuary: the powers of heaven gather to attend the mystery of our deliverance.

### 85–86

Now is the moment for those who watch to take their places in order. Let everyone direct the eyes of the mind toward what is being said.

### 87–88

Look: the priest makes ready to enter the Holy of Holies, to open the entrance to the heavenly kingdom for those who would come in.

### 89–90

Look: he approaches the threshold of the royal dwelling, there to receive the power needed for the mysteries that his hands will celebrate.

### 91–92

Look: the King above reaches out the hand of the Spirit to him and lays in his hand the seal of the divine Name, with which to mark his sheep.

### 93–94

Look: he clothes the priest in the glorious robe of the immortals, so that he may cover the shame of people whom guilt has left exposed.

### 95–96

Look: he sends him to care for the flock entrusted to him. The priest raises his voice and calls each of the sheep by name.

### 97–98

Look: the sheep, lambs and ewes gather together, and he sets upon them the life-giving seal carried by the word of their Lord.

### 99–100

Look: by their spoken words he leads them, as it were, into a furnace, asking of them one confession of the Creator’s Name.

### 101–102

The divine command holds the priest as one holds a pen, though the writing is accomplished spiritually: through him it inscribes body and soul in the book of life.

### 103–104

His spoken word becomes a staff that drives away the darkness of error, the darkness that had blinded the candidates and kept them from understanding.

### 105–106

He raises his voice and directs them to renounce the Evil One, his power, his angels, his service, and the errors by which he deceives.

### 107–108

First they reject the mastery of the one who enslaved them. Then they acknowledge the strength of the Creator who has brought them into freedom.

### 109–110

Two declarations belong to everyone approaching the Church's mysteries: the rejection of evil and a confession of faith in the Maker.

### 111–112

Aloud the candidate declares: “I renounce the Evil One and his angels. I will have no fellowship with him, not even in what I say.”

### 113–114

The priest stands between the candidate and the unseen kingdom. He asks: “Whose servant do you wish to be from this day onward?”

### 115–116

He learns whom the candidate chooses to call Lord, and then enrolls that person among heaven's firstborn.

### 117–118

The candidate's face is turned away from Satan and his angels. The priest then traces upon the forehead the likeness, or sign, of divine being.

### 119–120

He repudiates the Evil One because his dealings are evil, and repudiates his angels as enemies of the word of truth.

### 121–122

The Evil One and all who take his side oppose the truth; whoever loves truth is therefore called to reject their allegiance.

### 123–124

Let the candidate take up the words of David, the son of Jesse: “Lord, I have hated those who hate you.” Let him demand an answer for the outrage done to the Creator's name.

### 125–126

Whoever comes to baptism enters a struggle against Satan, against his angels, and against the service he exacts.

### 127–128

Narsai calls some of Satan's “angels” human deceivers, people who, in his judgment, serve falsehood through practices filled with wickedness.

### 129–130

He counts Mani among them: a dangerous wolf wearing the likeness of a lamb, drawing the sheep of the flock off their proper path.

### 131–132

Next he names Valentinus, accused of violating truth and covering over the resurrection of the dead with empty arguments.

### 133–134

He names Arius, too, whom he attacks for teaching an inequality within the Godhead; Narsai compares this doctrine to an illness worse than leprosy.

### 135–136

Eunomius follows, portrayed as a cunning serpent whose poisonous bites harm the souls of those who listen to him.

### 137–138

Apollinaris is another target. Narsai says he builds falsehood into the very structure of truth, yet feels no shame.

### 139–140

He also names Paul, whom he accuses of stubbornly belittling the power of the Father's Word.

### 141–142

Eutyches is added to the company: in Narsai's account he loses his way by attributing suffering to the One who is beyond suffering.

### 143–144

Like a merchant who adulterates what he sells, this teacher, Narsai charges, mixes the living divine nature with the sufferings of the body.

### 145–146

Narsai judges his offense still greater than those of the others, and says that in this way he gives the Accuser even more assistance.

### 147–148

Through such teachings, Narsai says, humanity's enemy misleads human minds, pouring into them the bitterness of his deceit.

### 149–150

His followers carry out the forms of that corrupt service and invent fresh deceits to enlarge it.

### 151–152

The worship in which they take pride is, in Narsai's polemical description, service to the deceiver; its mysteries are not the mysteries of truth.

### 153–154

He accuses the teachers he calls heretics of serving that enemy in many guises, led astray by his devices and leading their hearers astray in turn.

### 155–156

For this reason he tells his hearers to keep clear of them, as one avoids uncleanness, and not to join in the practices he condemns.

### 157–158

He urges them to name such works evil, turn away from them, and refuse participation in their rites.

### 159–160

The inventions of the Evil One and of those who heed him, Narsai says, are packed with injustice; hidden maladies lie beneath their apparent cleverness.

### 161–162

He places circuses, athletic spectacles, theaters, and the clamorous songs composed for them among the distractions associated with that error.

### 163–164

He also mentions divination and magical arts in their many forms, including beguiling gestures of the eyes, enticing sounds, and encounters that lure people from the road.

### 165–166

When a disciple of truth is instructed, these are the things renounced. Only then does the candidate come forward to confess the faith.

### 167–168

The candidate gives audible expression to the decision of the heart: “I have left the Evil One behind and turned toward the Creator.”

### 169–170

The words spoken aloud put the demons to shame: “Hear me, rebels! I have nothing in common with you.”

### 171–172

The candidate's confession gladdens the assemblies of heaven: “Come, you spiritual beings; rejoice with me! I have escaped destruction and come back to life.”

### 173–174

“I belong among your companions in service and wish to take part in your work. I too desire to serve the Lord whom you serve.”

### 175–176

Thus the wanderer calls himself a soldier of the heavenly kingdom: someone who fled, but has returned to seek refuge with the King of kings.

### 177–178

First he petitions the stewards of the holy Church, asking them to bring him before the King's doorway so that his plea may be heard.

### 179–180

These stewards are the priests who minister the mysteries. The treasury of the Spirit has been entrusted to them, that they may distribute its riches.

### 181–182

The wanderer, an exile, comes to one of these priests, asking to be released from the power of the Evil One who took him prisoner.

### 183–184

Like an exile without clothing or protection he stands before the priest, exposing the exhaustion and suffering he endured in the house of his captors.

### 185–186

“For the King's sake,” cries the captive to the royal servants, “go to the King and plead for me, that he may receive me kindly.”

### 187–188

“Enter and tell him: One of your servants has come back from captivity. He begs, in love, to behold your face.”

### 189–190

“I was made captive to a servant who rebelled against your rule. Free my life from his power so that he may no longer bring me low.”

### 191–192

“I am your servant, good Lord, a child of your handmaid. Why must I serve a wicked slave who has turned against you?”

### 193–194

“Why did I wrongfully serve this worker of every wrong? Rescue me from him. Let me be yours, for I already belong to you.”

### 195–196

Such is the speech the wanderer fashions on the day of his return, in the pattern of the story of the younger son.

### 197–198

The parable was given for his sake; it is fitting that he shape his plea according to the words handed down in Scripture.

### 199–200

He is the one of whom the Gospel tells: he wandered away, departed, changed direction, and came home. His departure and repentance are written there.

### 201–202

Now the written story becomes reality, and abundant mercies go out to meet the returning exile and welcome him.

### 203–204

The heavenly assemblies celebrate his repentance. They accompany him as one who had died and has come back to life.

### 205–206

Only the Accuser grieves over his return: the captive has torn through his nets, broken his traps, abandoned him, and fled.

### 207–208

The sinner has escaped bitter servitude and found asylum with the good Lord, whose love is sweet.

### 209–210

The exile has returned from banishment to the One who formed him. Now he petitions for permission to enter and see the King's face.

### 211–212

His plea becomes an accusation against the one who held him captive: by God's own law, he brings charges against his oppressor.

### 213–214

He places the pen of his spoken words into the hands of the King's servants; they put the case into writing and carry it before the Judge.

### 215–216

He asks the priests to stand as advocates in the case against him. While he keeps silent, they speak in his defense.

### 217–218

At the hour of the mysteries the priest stands, as in a court of law, to bring an accusation against the devil on behalf of sinners.

### 219–220

The sinner too stands there like a poor person who has been cheated, pleading that mercy may come to his aid in the judgment.

### 221–222

Uncovered and stripped before the Judge, he allows his poverty and shame to speak for him, hoping that compassion will provide him a covering.

### 223–224

Without any defense to hide behind, he presses his claim against his adversary, so that the King may see him and swiftly settle his cause.

### 225–226

He bends his knees and lowers his head in embarrassment, ashamed to raise his eyes toward the Judge above.

### 227–228

He puts on sackcloth and approaches to beg for mercy, remembering how he had lived in bondage to the Evil One.

### 229–230

His kneeling during the mysteries tells two stories at once: that he has fallen, and that he is a debtor offering what he owes.

### 231–232

In this posture he remembers the fall in Paradise and brings a case against Satan, who misled his ancestor.

### 233–234

Fear keeps his face turned to the ground until he hears a word of pardon. Only then does he recover courage.

### 235–236

He waits for the priest to present his petition to the Judge and to return to him, through oil and water, the written charter of freedom.

### 237–238

He also brings a sponsor into the place of judgment, to bear witness that his preparation and desire of heart are genuine.

### 239–240

He promises sincerely to remain faithful to the truth; his companion stands surety, affirming that the promise comes from an honest heart.

### 241–242

That companion becomes a guide for his speech and conduct, showing him how to lead a spiritual life.

### 243–244

He calls the candidate by name and presents him before the guardians, to be acknowledged as an heir, a son, and a citizen of the kingdom.

### 245–246

The priest enters the name of the one who had been lost in the records, depositing it among the royal archives.

### 247–248

He stations the person like a sheep at the gate of the fold, marks the body with a sign, and brings the newcomer into the flock.

### 249–250

Before those watching, he holds in his hand the mark made with oil; through something visible he announces the force of something hidden.

### 251–252

It is a sign set before bodily eyes, pointing toward the unseen power concealed within the visible anointing.

### 253–254

O human being formed of earth, who marks the flock with its Master's sign! Through an outward symbol you stamp upon it his hidden name.

### 255–256

O earth-born minister, holding the Spirit at the tip of your tongue! By the words of your mouth you cut away the wrongdoing of both soul and body.

### 257–258

O mortal, whose mouth contains a great spring! You offer the people of your own kind a drink of life that cannot die.

### 259–260

O poor one, child of the poor, suddenly made rich! You now distribute the Spirit's abundance, wealth your ancestors never possessed.

### 261–262

O earth-born creature, whose very dust declares its lowliness! Yet it has received authority to fashion a new creation for itself.

### 263–264

The Good One taught the children of his house the work of new creation, so that through his own creative art they might renew what had been made.

### 265–266

Human wrongdoing tore down the lofty work of his hands; and he gave human beings the power to build it up once more.

### 267–268

He saw his handiwork worn and aged by mortality, and opened for it a way toward life that cannot die.

### 269–270

He saw the pillars of his house trembling under the weight of suffering; so he set their foundations deep in the waters and made them firm.

### 271–272

Through yielding water he chose to give firmness to fragile bodies, and by the Spirit's strength to steady powers that were failing.

### 273–274

His command prepared a mysterious furnace of water, heating it not with ordinary flame but with the Spirit and the power of his will.

### 275–276

He made the very creature he had fashioned an artisan of its own restoration, able to be recast in the furnace of water and the Spirit's heat.

### 277–278

Come and behold the wonder wrought within mortal humanity: by the ministry entrusted to it, a mortal dies and lives again.

### 279–280

Come, inquire into the mystery of our death within the waters, and consider the marvel enacted there for us beyond what the eye can see.

### 281–282

Come close to the guardians of the Church's treasures and hear how, through water, they bestow life.

### 283–284

Let us enter with them the hidden Holy of Holies and learn how the mysteries of dying and living are to be understood.

### 285–286

Baptism is a mystery of both death and life: these two acts become one in the single ministry of the priesthood.

### 287–288

The Creator has chosen to reveal his power through the priests, entrusting to their service the great wealth of his generosity.

### 289–290

He has appointed priests as stewards of his estate, so that faithful servants may distribute its riches to the children of his household.

### 291–292

To them he has given the signet of his incomprehensible divine Name, that they may stamp human beings with the holy Name.

### 293–294

They continually impress the mark of that Name upon his flock: human ministers sign other humans in the threefold Name.

### 295–296

On his fingertips the priest holds the oil like a blade of iron, and with its sharpness marks both the body and the powers of the soul.

### 297–298

By the words of his mouth this mortal minister gives the oil its keen edge, as though sharpening iron to cut away wrongdoing.

### 299–300

He pronounces the three Names in order, one after another, and by this threefold calling completes the mystery of our deliverance.

### 301–302

O frail human being, what a mighty marvel passes through your service! No mouth can fully express the strength of its meaning.

### 303–304

O lowly one, how high your weakness has been raised! The mind cannot follow you to the place you have been brought.

### 305–306

O human being—and here I speak to the priest—what authority has been given you: you are appointed to offer life itself.

### 307–308

Through his ministry the priest gives life to those who share his nature, and opens before fellow servants a path toward the life to come.

### 309–310

He becomes a mouth for the body's members and the soul's faculties, speaking on behalf of all the words that announce forgiveness.

### 311–312

He sets oil and water in place like foundations. Upon them, through his spoken words, he raises the Name of the divine Being.

### 313–314

With flowing oil and yielding water he melts down the body; in place of ordinary clay, he transforms it into pure gold.

### 315–316

Who would not marvel that our poverty has been granted such power, so that it may be enriched by a gift beyond understanding?

### 317–318

Like a keeper of treasures the priest stands at the sanctuary door, using the keys of words spoken from his mouth to open the way to life.

### 319–320

He invokes the three Names over the oil and consecrates it, so that through its holiness it may cleanse the impurity of human beings.

### 321–322

With the Name that cannot be seen he signs the body that can be seen; the keen force of that Name penetrates as far as the soul.

### 323–324

Marvel at what a human being performs through a power not his own: he marks frail bodies, yet the inward person feels the effect.

### 325–326

He also acts as a physician for the body's members, touching the outside so that the healing action reaches what lies within.

### 327–328

He brings the remedies of his art to body and soul, and by divine power heals what is open to sight and what is hidden.

### 329–330

By God's help he prepares the remedy placed in his hands, and its power tends every sickness without running short.

### 331–332

He opens the door of the holy temple like a dispensary of medicines, tending the illnesses and binding the wounds of his fellow servants.

### 333–334

With an outward marking he reaches diseases concealed within, and then applies the medicine of the Spirit through the sign of water.

### 335–336

His audible voice proclaims the hidden strength at work, while his tongue distributes spiritual riches.

### 337–338

As he signs the flock, he speaks words into its ears, and the flock listens lovingly when the three Names are announced.

### 339–340

He seals his proclamation in the Name of the Father, the Son, and the Spirit, confirming in those Names the one who is being baptized.

### 341–342

The priest draws the three Names upon the candidate's face as a protecting shield, so that the tyrant may see the likeness of divine majesty upon a human forehead.

### 343–344

This is why the forehead is signed: to put the demons to shame. When they recognize the sign upon a human head, they are confounded and driven back.

### 345–346

The mysteries of oil and water are performed also for this reason: they provide armor against the spirits' assaults and the unseen warfare they wage.

### 347–348

The oil that anoints those born of earth is a defense. Armed with it, they need not be taken prisoner by hostile spirits in a battle hidden from human sight.

### 349–350

They bear the great seal of the King of kings, stamped upon them so that they may take their places as soldiers in the struggle of the spirit.

### 351–352

Upon the brow they receive the mark of a spiritual enlistment, a bright sign that may be seen before angels and human beings alike.

### 353–354

They stand like courageous soldiers at the King's gate, while the priest takes his place before them, a commander at the head of an army.

### 355–356

In the hour of the mysteries he arranges their ranks as though battle were beginning, making them ready to launch sharp arrows against their adversary.

### 357–358

These arrows are words. He sets them upon their lips and directs them toward the Evil One, whose prisoners they had formerly been.

### 359–360

He places a mark before their eyes toward which they are to aim; and he draws the words upon their tongues taut as arrows against a bowstring.

### 361–362

As the struggle begins, they are brought to examination: what they confess reveals the intention of their minds and tests their readiness.

### 363–364

The priest remains at the front of their company, showing them the true mark, so that they may direct their answer and their allegiance aright.

### 365–366

They renounce the banner of the Evil One, his might, and his angels. Then the priest marks their brows with the banner of the King. **[The Syriac wording around the repeated “mark/target” requires review.]**

### 367–368

Renunciation and confession belong together: they reject the Evil One and, without divided hearts, profess faith in the divine Name.

### 369–370

Through the priestly ministry they enter a covenant with God, promising that their actions will never again return them to Satan's service. **[A form in the Syriac text referring to priesthood is uncertain.]**

### 371–372

They entrust their pledge to the priest in words arising from the mind and heart. He brings that promise before God's gracious will, as one submitting it to the King.

### 373–374

He holds, as it were, the register kept at the entrance to the royal house: from the palace he has received authority to write human names upon it.

### 375–376

He calls the King's servants by name, summons them forward one by one, and sets the mark of oil upon each person's face.

### 377–378

With audible words he declares the power that lies hidden in this action. He makes known to whom these people belong, and whose Name is their seal.

### 379–380

Of each he announces: “This person is a servant of the King of kings, above and below, and bears his Name as a sign of service according to his will.”

### 381–382

The priest joins the divine Name to the oil in his hands and, as he makes the sign, invokes the Father and the Son and the Holy Spirit.

### 383–384

He declares: “This person is signed with the three equal Names.” Among them, he proclaims, there is neither elder nor younger.

### 385–386

He does not say, “I sign this person,” but, “This person is signed.” The seal he applies belongs not to him, but to his Lord.

### 387–388

He is a mediator appointed to minister by grace. Because the power is not his own, this ministry can drive away wrongdoing and bestow the Spirit.

### 389–390

The visible oil shows forth the invisible strength carried by the divine Names, a strength able to sustain our weakness from within.

### 391–392

He invokes the three Names as he anoints the whole person, that hostile demons and troubling passions may have no power to injure the one receiving the sign.

### 393–394

It is not oil in itself that protects a human being from harm. Divine power is what gives strength to our frailty.

### 395–396

Oil is a sign that makes divine power known: by means of something visible, God gives assurance of what he accomplishes in secret. **[The precise wording of line 396 is textually difficult.]**

### 397–398

Through that power, body and soul receive fresh courage and strength; they need no longer tremble before the injuries of death.

### 399–400

Like athletes they step down into the arena, there to contend against the timid and deceptive thoughts that rise within them.

### 401–402

Such strength is conveyed in the anointing—not because the oil possesses it of itself, but because the Spirit gives the oil its power.

### 403–404

The Spirit strengthens the anointing performed with frail oil, making its effect firm through the sacred work accomplished in it.

### 405–406

Thus body and the inward powers of the soul are established in strength, and the newly signed go out confidently to oppose the Evil One.

### 407–408

The demons see the seal of God's Name upon a person and shrink away, for they recognize the honored Name carried in that sign.

### 409–410

The divine Name shines out from the mark between the eyes, and the cunning spirits are ashamed even to look upon it.

### 411–412

A second Sun has risen from heaven upon the human head. With his rays he scatters error, the second darkness.

### 413–414

Come, human being: praise and exalt the One who has honored you! Through his gift he has made even your body like a second sun.

### 415–416

Come, you who owe him everything: repay your debt with praise. He has ransomed you from bondage to the Evil One and to Death.

### 417–418

Come, mortal creature: glorify the power of God, who has planted in your mortal life the capacity to sow the seed of life.

### 419–420

With every mouth, descendants of Adam, children of the earth, raise your cry to the One who lifted you from dust toward his own greatness.

## Working edition · sources and cautions

Completed as a rough draft, not certified by a Syriac scholar. The Syriac transcription remains uncollated in full with Mingana’s original printing; its vowels, points and textual variants have not been fully verified. Earlier difficult readings include 16, 32, 36, 54 and 71–72; later problems include the exact Syriac at 365–366, 369–370 and 395–396. The judgments against theologians in 127–160 are Narsai’s historic polemic, not editorial endorsements. Passage boundaries and some legal/liturgical terms need specialist checking. Distinguish this provisional reading from any strict twelve-syllable poetic adaptation.

**Syriac source / Fonte siriaca:** Digital Syriac Corpus, work / opera 66; transcription / trascrizione William Toma; TEI James E. Walters; CC BY 4.0, https://raw.githubusercontent.com/srophe/syriac-corpus/main/data/tei/66.xml. **Interpretive check / Confronto:** R. H. Connolly, *The Liturgical Homilies of Narsai* (1909), pp. 33–45.
