# Narsai Homily XXII — English and Italian translation progress

**Status, October 23, 2026:** All **420/420 numbered Syriac lines (100%) have provisional English AND Italian prose drafts**, including the preceding unnumbered liturgical response. The readings are grouped into 210 matching line-pair paragraphs in both languages.

| Syriac numbered range | English | Italian |
|---|---|---|
| Unnumbered response and 1–100 | Complete provisional draft | Complete provisional draft |
| 101–180 | Complete provisional draft | Complete provisional draft |
| 181–260 | Complete provisional draft | Complete provisional draft |
| 261–340 | Complete provisional draft | Complete provisional draft |
| 341–420 | Complete provisional draft | Complete provisional draft |

**Final complete deliverables:**
- `narsai_baptism_new_english_consolidated_lines001-420.md`
- `narsai_baptism_new_english_consolidated_lines001-420.docx`
- `narsai_baptism_new_italian_consolidated_lines001-420.md`
- `narsai_baptism_new_italian_consolidated_lines001-420.docx`

**Important limitation:** These are new, rough, provisional prose interpretations, not fully scholarly certified translations. The primary Syriac control is the uncorrected Digital Syriac Corpus TEI work 66 (William Toma / James E. Walters, CC BY 4.0). R. H. Connolly, *The Liturgical Homilies of Narsai* (1909), pp.33–45, has been consulted as an interpretive check, not reproduced verbatim. No further Mingana character-by-character collation was undertaken. Wording at 365–366, 369–370 and 395–396, plus earlier marked passages, requires specialist verification. Original Unicode Syriac and prior English/Italian adaptations have not been modified.

**Automation can now be disabled:** both languages cover all 420 numbered Syriac lines.
